stepper_carrier rev A - bare boards only, no assembly
Size 126 x 146 mm, 4 layers, 1.6 mm FR-4, outer 1 oz, inner 0.5 oz, HASL
Layer order: see LAYER_ORDER below (read back from the X2 attributes)
Min track 0.25 mm, min space 0.2 mm, min hole 0.8 mm; no vias
PTH and NPTH drill files are separate.

LAYER_ORDER
| Layer | Position | File |
| L1 | top | `stepper_carrier-F_Cu.gtl` |
| L2 | inner | `stepper_carrier-In1_Cu.g1` |
| L3 | inner | `stepper_carrier-In2_Cu.g2` |
| L4 | bottom | `stepper_carrier-B_Cu.gbl` |
